#!/bin/sh

echo 13\n\n\necho 14;

echo -EeE \\\\\\

echo -E -E -E -E -e -E -e -e -e -e -E ab \\\\\\

echo 13\\\n14; echo \n ;

echo \n13\n14\n;
