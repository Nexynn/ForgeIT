toto=12; echo $toto;
