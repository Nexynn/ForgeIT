#!/bin/sh

echo 13\\necho 14;\\necho \\n13
