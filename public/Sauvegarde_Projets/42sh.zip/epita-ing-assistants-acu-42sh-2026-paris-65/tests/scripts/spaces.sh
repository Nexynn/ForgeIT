"    /bin/echo" 12
