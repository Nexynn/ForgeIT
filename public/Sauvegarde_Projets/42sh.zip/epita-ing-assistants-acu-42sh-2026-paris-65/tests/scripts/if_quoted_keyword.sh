if echo 12; then echo 14; 'fi'; fi
