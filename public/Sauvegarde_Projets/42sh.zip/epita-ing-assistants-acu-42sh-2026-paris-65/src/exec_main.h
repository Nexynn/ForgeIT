#ifndef EXEC_MAIN_H
#define EXEC_MAIN_H

int exec_main(int argc, char **argv);

#endif /* ! EXEC_MAIN_H */
