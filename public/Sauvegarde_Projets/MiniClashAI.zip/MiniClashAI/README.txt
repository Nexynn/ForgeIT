Before you begin, make sure to download the TensorFlow library. (pip install tensorflow)

Once that's done, you can launch the MiniClashAI.exe and begins using the program.